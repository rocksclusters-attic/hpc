# Copyright (c) 2009      Sun Microsystems, Inc.  All rights reserved.
#                         Use is subject to license terms.

#
# Perl module shared by all frontend commands (ct*) 
#

{        # start lexical scope

package Share;
use Exporter;

@ISA = qw(Exporter);
@EXPORT = qw(
             command_main
             gen_summary
             init_basic
             optusg
             optusg_central
             optusg_command
             optusg_general
             optusg_p
             syntax_err
            );

require 5.8.4;
use strict;

use FindBin qw($Bin $Script);

use lib "$Bin/../lib/CPAN";

# turn off run-time check for symbolic references, which is recommended 
# while using FileCache::cacheout.
no strict 'refs'; 

# for dispatch()
use POSIX ":sys_wait_h";
use FileCache qw(cacheout);

# CPAN module; for via_telnet()
use Expect;

# CPAN module; for password no-echo
use Term::ReadKey qw(ReadMode ReadLine);

# for time stamps and summary log
use POSIX qw(strftime);

use Sys::Hostname qw(hostname);

# for gen_summary
use File::Basename qw(basename);

# for i18n
use POSIX qw(locale_h);
use Sun::Solaris::Utils qw(bindtextdomain textdomain gettext);

# declare global variables; all globals are capitalized.
#
our $Version = 8;         # product version
our @Nodes = ();          # array of nodes to operate on.
my (
       $Backend,          # backend command
       $CmdStr,           # command string used to invoke the backend command. 
       $CMethod,          # connection method
       $CMethodPath,      # full path to connection method (e.g., /usr/bin/ssh)
       $DoneStr,          # string to indicate command execution is successful
       $ErrStr,           # string to indicate command execution has error
       $GenNList,         # generate node list files
       $HistoryLog,       # ct_history.log
       $Host,             # local host name 
       $HPCrhosts_msg_type,  # type of msg ('none', 'info', 'warn') 
       $KeepDir,          # directory to keep log files of all nodes 
       $KeepLogs,         # keep node-specific logs (-k)
       $Lib,              # lib directory where all backends are
       $LocalOp,          # local initiation.
       $Log,              # log file for each node
       $LogDir,           # log directory
       $LogFile,          # log file name 
       $NodeListDir,      # directory to store node lists
       $Master,           # master node
       $MsgDir,           # location for message catalog
       $MsgFile,          # message catalog
       $Op,               # operation (install, remove, etc) 
       $PkgStr,           # name of package followed by "::"
       $ResultPath,       # master result file
       $SaveArgv,         # saves ARGV
       $StartTime,        # command starting time
       $SummaryLog,       # ct_summary.log
       $TimeStamp,        # named pipe for time stamps.
       $TmpDir,           # temp dir while command is run
       $WarnStr           # string to indicate command execution has warning 
);    

#
#:   - cleanup:    
#         cleanup temp directory before exit 
#    given: $TmpDir 
#
sub cleanup {

    system "rm -rf $TmpDir 2>/dev/null";    

    # restore original terminal mode just in case it's set to 'noecho'
    # when cleanup() is called, i.e., while prompting for password.
    ReadMode (0);
}


#
#:   - collect_results:    
#         collect results from nodes and put them in a master result file. 
#
#    given:  global @Nodes, $ResultPath
#
#    return: 1 if successful.    
#
sub collect_results {

    # create master result file
    my $master_res = $ResultPath;
    FileCache::cacheout $master_res;
    my $cachefile = $PkgStr . $master_res;

    # get the result of each node
    my ($status, $line);
    foreach my $node (@Nodes) {
        # update status if we find a legitimate status line. 
        if (open (RES, "$TmpDir/$node.result") && ! eof (RES)) { 
            while (<RES>) {
                if (/($DoneStr|$ErrStr)/o) { 
                    $status = $_;
                } else {
                    # carry over warning messages to the master result file.
                    print $cachefile $_;
                }
            } 
        }
        close (RES);        
        print $cachefile $status;
    }

    close ($cachefile);
    return 1;
}

#
#:   - command_main:    
#         main part of each command 
#
#    given:  0) string containing all options requiring arguments.
#            1) string containing all options without arguments.
#            2) reference to the options hash (key: switch, value: args).
#
#    return: 0 if success.    
#
#    note:   Perl programs using this subroutine must supply their
#            own sub command_usage() and opt_check().
#
sub command_main {

    my ($optdef_w, $optdef_wo, $opthashref) = @_;

    &init;

    if (@ARGV == 0) {
        &main::command_usage;
        exit 0;
    }

    #!    - parse command line options    
    if (! &opt_parse ($optdef_w, $optdef_wo, $opthashref)) {  
        &fail (gettext ("Command syntax error"));
    } 

    #!    -h switch specified, prints usage and exit
    if (exists $opthashref->{h}) {
        &main::command_usage;
        exit 0;
    }
    
    #!    - check if user is root
    &is_root || 
        &fail (gettext ("You must be root to run this command"));

    #!    - command-specific options checks
    &main::opt_check;

    #!    - get nodelist and connection method
    &setnodeinfo ($opthashref); 
    
    #!    - set command string to be passed to backends 
    &setcmdstr ($opthashref);
    
    #!    - invoke the operation 
    if ($LocalOp) {
        # local initiation

        system ("$Lib/$CmdStr") &&
            &fail (gettext ("Command completed with errors"));

    } else {
        # centralized initiation
        &dispatch;

        #!    - collect results
        &collect_results;

        #!    - generate summary report and update /etc/sunhpc_rhosts if needed
        &gen_summary ("$StartTime", "$Bin/$Script $SaveArgv", $ResultPath, $Op, $HPCrhosts_msg_type, $GenNList) ||
            &fail (gettext ("Command completed with errors"));

    }

    &cleanup;
    return (0);
}


#
#:   - create_nlistfile:    
#         create a node list file 
#
#    given:  0) a file path 
#            1) an array containing nodes
#            2) a time stamp (optional)
#    does:   write the nodes to the file, separated by newlines. 
#
sub create_nlistfile {
    my ($file, $arref, $time) = @_;

    open (NLIST, ">$file") || 
          &fail (gettext ("Failed to open $file: $!"));

    if ($time) {
        print NLIST "# $time\n#\n";
    }

    foreach my $node (sort (@$arref)) {
        print NLIST "$node\n";
    }
    close (NLIST);

    return 1;
}


#
#:   - dispatch:    
#         dispatch the command to specified nodes using rsh/ssh/telnet
#
#    given:  @Nodes, $CMethod, CmdStr 
#    return: 1 if successful
#
sub dispatch {

    my ($password, $verify);

    # prevent "Broken Pipe" errors.
    $SIG{PIPE} = 'IGNORE';

    # create temp dir for node-specific result files and pipes.
    if ( ! -d $TmpDir) { 
        mkdir ($TmpDir, 0755) || 
            &fail (gettext ("Can not create $TmpDir: $!"));
    }

    # filename prefix for node-specific log file ($Script.log.$node)
    $Log = "$TmpDir/$LogFile";
    # directory to store log files of all nodes
    if ($KeepLogs) {
        if (! -d $KeepDir) { 
            mkdir ($KeepDir, 0755) || &fail (gettext ("Can not create $KeepDir: $!"));
        }
        $Log = "$KeepDir/$LogFile";
    }

    # keep more files open than the system permits 
    $FileCache::cacheout_maxopen = 1024; 

    my (@procs, $node);
    my (%nodestat, @valid_nodes);

    # find the status of each node and store them for later use. 
    my $do_remote;
    foreach $node (@Nodes) {
        if (! system "$Lib/lookup_hosts $node") {
            # lookup is successful
            # check if on the local host
            if (system "$Lib/lookup_hosts $node $Host") {
                $nodestat{$node} = 'remote';
                $do_remote = 1;
            } else {
                $nodestat{$node} = 'local';
            }
            push (@valid_nodes, $node);
            next;    
        } else {
            $nodestat{$node} = 'unknown';
        }
    }

    # prompt for password only if telnet and remote nodes are to be connected, 
    if ($CMethod eq 'telnet' && $do_remote) {
        ReadMode ('noecho');
        while (1) {
            print "\n", gettext ("Enter password"), ": ";
            $password = ReadLine (0);
            print "\n", gettext ("Confirm password"), ": ";
            $verify = ReadLine (0);
            ($password eq $verify) && last;
            print "\n", gettext ("Password confirmation failed. Try again"), ".\n";
        }
        ReadMode (0);
        print "\n\n";
    } 

    # start time stamps 
    my ($writer_pid, $reader_pid);
    &timestamp_start ($writer_pid, $reader_pid);

    #use Data::Dumper;
    #print Dumper %nodestat;

    # fork 1 process per node
    foreach $node (@Nodes) {
        if (my $pid = fork) {
            # parent

            # save all child's process id.
            push (@procs, $pid);

        } else {
            if (! defined $pid) { 
                post_error ($node, gettext ("Can not fork: $!"));
                next; # move on to next node
            }
            # child

            # reset signal handler for the child. 
            $SIG{INT} = sub { exit };

            if ($nodestat{$node} eq 'unknown') {
                post_error ($node, gettext ("Unknown host"));
                exit (1); # exit fork
            } 

            my $log = "$Log.$node";
            FileCache::cacheout $log;

            if ($nodestat{$node} eq 'local') {
                print "$Script: ", gettext ("Executing command on node $node locally"), " ...\n";
                &via_local_rsh_ssh ($node, $log, "local");
            } else {
                print "$Script: ", gettext ("Executing command on node $node via $CMethod"), " ...\n";
                if ($CMethod eq "telnet") {
                    &via_telnet ($node, $log, $password); 
                } else {
                    &via_local_rsh_ssh ($node, $log, $CMethod);
                }
            }
            &process_output ($node, $log);

            # don't let child fall back into main code.
            exit;    
        }    
    }

    # wait for all child processes to finish
    foreach my $child (@procs) {
        waitpid ($child, 0);
    }

    &timestamp_stop ($writer_pid, $reader_pid);

    return 1;
}

#
#:   - fail:    
#         cleanup and die. 
#
#    given:  0) error message 
#    does:   clean up and die 
#
sub fail {
    &cleanup;
    die ("$Script: $_[0].\n");
}


#
#    gen_summary: 
#          - generates summary on stdout and appends it to ct_summary.log. 
#          - gives info/warning msg on /etc/sunhpc_rhosts if specified. 
#          - generates node lists if specified.
#
#    given:  six strings, i.e.,  
#            0) command start time (in locale's format, i.e., strftime/date %c)
#            1) full path to the command invoked + command arguments
#            2) full path to the result file 
#            3) operation (install/remove/startd/stopd)
#            4) type of sunhpc_rhosts msg (info/warn/none) 
#            5) generate node list files? (yes/no)
#
#            Note: all arguments should be quoted strings
#
#   return: 0 if all nodes succeeded
#           1 if some nodes failed
#
sub gen_summary {

    my ($start_time, $cmdstr, $resultpath, $op, $hpcrhosts_msg_type, $gen_nlist) = @_;

    # get the name of the command, e.g., ctinstall, ctgui, etc.
    my @cmdarr = split (/ /, $cmdstr);
    my $cmd = basename ($cmdarr[0]);

    if (! -d $LogDir) {
        mkdir ($LogDir, 0755) || 
            &fail (gettext ("Can not create $LogDir: $!"));
    }

    # read from the result file
    open (RESULT, $resultpath) ||
            &fail (gettext ("Failed to open master result file: $!"));

    # append to summary file 
    open (SUMMARY, ">>$SummaryLog") ||
            &fail (gettext ("Failed to open $SummaryLog: $!"));

    # log timestamp/command line 
    &print_both (*STDOUT, *SUMMARY, "\n##### " . gettext ("Command Summary") . " #####\n\n$cmdstr\n");

    my $finish_time = POSIX::strftime "%c", localtime; 
    &print_both (*STDOUT, *SUMMARY, "\n" . gettext ("Start") .  ":  $start_time\n");
    &print_both (*STDOUT, *SUMMARY, gettext ("Finish") . ": $finish_time\n");

    # process result file to get list of nodes that succeeded and list
    # of nodes that failed.
    my (@pass, %fail, %warn, $node);

    while (<RESULT>) {
        /^\((.*)\): .*/;
        $node = $1;
        if (/$DoneStr/o) {
            push (@pass, $node);
            next;
        }        
        if (/$ErrStr(.+)/o) {
            $fail{$node} = $1;
            next;
        }
        # save all warning messages for a node
        if (/$WarnStr(.+)/o) {
            push (@{$warn{$node}}, $1);
        }
    }
    close (RESULT);

    my @fail = sort keys (%fail);
    my @warn = sort keys (%warn);

    my $passcnt = @pass;
    my $failcnt = @fail;
    my $warncnt = @warn;
    &print_both (*STDOUT, *SUMMARY, sprintf ("\n%s:       %3d\n", gettext ("Total number of nodes"), $passcnt+$failcnt));
    &print_both (*STDOUT, *SUMMARY, sprintf ("\n%s: %3d\n", gettext ("Number of nodes that passed"), $passcnt));
    &print_both (*STDOUT, *SUMMARY, sprintf ("%s: %3d\n",   gettext ("Number of nodes that failed"), $failcnt));

    if ($gen_nlist eq "yes") { 
        # directory to store node lists 
        if (! -d $NodeListDir) { 
            mkdir ($NodeListDir, 0755) || &fail (gettext ("Can not create $NodeListDir: $!"));
        }

        &print_both (*STDOUT, *SUMMARY, "\n" . gettext ("Nodes recorded in") . ":\n");

        # $passcnt > 0
        if ($passcnt) {
            &create_nlistfile ("$NodeListDir/$cmd.pass$$", \@pass, $finish_time);
            &print_both (*STDOUT, *SUMMARY, "\n    $NodeListDir/$cmd.pass$$\n"); 
        }
    }

    # if $failcnt > 0, list failed nodes with errors 
    if ($failcnt) {
        if ($gen_nlist eq "yes") { 
            &create_nlistfile ("$NodeListDir/$cmd.fail$$", \@fail, $finish_time);
            # if $passcnt = 0, throw in a blank line here.
            (!$passcnt) && &print_both (*STDOUT, *SUMMARY, "\n"); 
            &print_both (*STDOUT, *SUMMARY, "    $NodeListDir/$cmd.fail$$\n"); 
        }
        &print_both (*STDOUT, *SUMMARY, "\n" . gettext ("Failed nodes with error messages") . ":\n\n");

        # list reason for each failure
        foreach $node (@fail) {
            &print_both (*STDOUT, *SUMMARY, "    ($node) : $fail{$node}\n");
        }
    }

    # if $warncnt > 0, list nodes with warning
    if ($warncnt) {
        &print_both (*STDOUT, *SUMMARY, "\n" . gettext ("Nodes with warning messages (check details in each node's local log files)") . ":\n\n");
        # list all warnings 
        foreach $node (@warn) {
            foreach my $msg (@{$warn{$node}}) {
                &print_both (*STDOUT, *SUMMARY, "    ($node) : $msg\n");
            }
        }
    }

    # point out log file locations
    print "\n", gettext ("Command summary is logged in"), ":\n\n    $SummaryLog\n";
    my $hoststr = gettext ("node");
    &print_both (*STDOUT, *SUMMARY, "\n" . 
        gettext ("Log files on each specified node are available at:") . 
        "\n\n    ($hoststr):$LogDir/ct_$op.log\n    ($hoststr):$HistoryLog\n\n"); 

    close (SUMMARY);

    # return with error $if failcnt > 0
    ($failcnt) && return (0);
    return (1);
}


#
#:   - getnodes:    
#         get a list of nodes from a nodelist file which contains one node
#         per line
#
#    given:  0) a nodelist file 
#            1) must exist flag (1-yes, 0-no)
#            2) reference to a node array
#    does:   sets the node array 
#
sub getnodes {

    my ($nlistfile, $must_exist, $aref) = @_;

    if (! open (NLISTFILE, "$nlistfile"))
    {
        if ($must_exist) {
            &fail (gettext ("Failed to open $nlistfile: $!"));
        } else {
            return 1;
        }
    }

    while (<NLISTFILE>) {
        chomp;
        # ignore blank lines and lines starting with #. 
        if (/^\s*$|^\s*#/) { next }; 
        # remove white space
        s/\s//g;
        # remove comment and following text
        s/#.*//;
        push (@$aref, $_);
    }
    close (NLISTFILE);
}

#
#    - init
#        initialize
#
sub init {

    # set up interrupt handler.
    $SIG{INT} = \&trap;

    # basic init tasks 
    &init_basic;

    # set values of other globals
    ($Backend = $Script) =~ s/^ct/n/;       # backend command.
    $GenNList = "no";                       # generate node list files
    $HPCrhosts_msg_type = 'none';           # type of msg ('none','info','warn')
    ($Op = $Script) =~ s/^ct//;             # operation 
    $LogFile = "ct_$Op.log";                # log file name
    $SaveArgv = join (" ", @ARGV);          # saves ARGV
    $StartTime = strftime "%c", localtime;  # command start time
    $TmpDir = "/tmp/.$Script$$";            # temp directory
    $ResultPath = "$TmpDir/$Script.result"; # master result file
    $TimeStamp = "$TmpDir/timestamp$$";     # named pipe for time stamps 

}

#
#    - init_basic
#        initializes global variables/constants shared by cli and ctgui 
#         (via gen_summary, etc)
#    does:  sets the globals
#
sub init_basic {

    $DoneStr = "INFO - \\[(DONE)\\] ";      # fixed string from backends (pass)
    $ErrStr =  "ERROR - ";                  # fixed string from backends (fail)
    $WarnStr = "WARNING - ";                # fixed string from backends (warn)

    $Host = hostname();                     # local host name    

    $Lib = "$Bin/../lib";                   # lib directory
    $LogDir = "/var/sadm/system/logs/hpc";  # log directory
    $NodeListDir = "$LogDir/nodelists";     # directory to store node lists.

    $PkgStr = "Share::";                    # package string    

    $HistoryLog = "$LogDir/ct_history.log"; # history log
    $SummaryLog = "$LogDir/ct_summary.log"; # summary log

    # i18n
    $MsgFile = "ct_installcli";
    $MsgDir = "$Lib/locale";
    setlocale (LC_ALL, "");
    bindtextdomain ($MsgFile, $MsgDir);
    textdomain ($MsgFile);

}

#
#:   - is_root:    
#         check if user is root.
#
#    given:  nothing
#    return: 1 if root; 0 if not root 
#
sub is_root {
    return ($< == 0);
}

#
#:   - opt_parse: 
#         parse command syntax and fills the options hash.
#
#    given:  0) string containing options requiring arguments. 
#            1) string containing options not requiring arguments. 
#            2) reference to the options hash (key: switch, value: args).
#    does:   in the options hash, values for options not requiring argument
#            are set to "", path arguments are translated to absolute paths.
#            
#    return: 1 if ok
#
sub opt_parse {

    use Getopt::Std;

    my ($optdef_w, $optdef_wo, $hashref) = @_;
    my $opt;
    
    getopts ("$optdef_w$optdef_wo", $hashref) ||
        &syntax_err (gettext ("Command syntax error"));

    # for options expecting argument, make sure they get one
    my @w = split (/:/, $optdef_w);
    foreach $opt (@w) {
        if ((exists $hashref->{$opt}) && ($hashref->{$opt} =~ /^-\w$/))  {
            &syntax_err ("-$opt " . gettext ("option requires an argument"));
        }
    }
    
    # if everything is fine, nothing should be left in @ARGV
    (@ARGV > 0) &&
        &syntax_err (gettext ("Command syntax error near") . " \"$ARGV[0]\"");

    # for options without argument, replace 1 with empty string to 
    # facilitate command string construction later.
    my @wo = split (//, $optdef_wo);
    foreach $opt (@wo) {
        if (exists $hashref->{$opt}) {
            $hashref->{$opt} = "";
        }
    }

    # translate specified paths to absolute and normalized paths. 
    translate_path ($hashref);

    #use Data::Dumper;
    #print Dumper $hashref;

    return 1;
}

#
#:   - optusg:
#         prints option usage
#
#    given:  0) an option
#            1) usage str
#
sub optusg {
    my ($opt, $str) = @_; 
    print "\t-$opt\t$str\n";   
}

sub optusg_p {
    &optusg ("p", gettext ("list of packages [separated by comma(,)]")); 
}

sub optusg_cat {
    print "\n\t<$_[0]>:\n\n";   
}

sub optusg_command {
    &optusg_cat (gettext ("Command specific"));   
}

sub optusg_central {
    &optusg_cat (gettext ("For centralized operations only"));   
    &optusg ("g", gettext ("generate node list files")); 
    &optusg ("k", gettext ("directory to store log files of specified nodes")); 
    &optusg ("n", gettext ("list of nodes [separated by comma(,)]")); 
    &optusg ("N", gettext ("file containing nodes [one node per line]")); 
    &optusg ("r", gettext ("remote connection method [preferred: ssh]") .
                  "\n\t\t" . 
                  gettext ("[options: ssh, telnet, or rsh (insecure)]") .
                  "\n\t\t" . 
                  gettext ("(no user interactions allowed in ssh connection)"));
    &optusg ("S", gettext ("full path to the alternate ssh executable")); 
    print "\n";
}

sub optusg_general {
    &optusg_cat (gettext ("General"));   
    &optusg ("h", gettext ("command help")); 
    &optusg ("l", gettext ("execute command on local host only")); 
    &optusg ("R", gettext ("full path of directory to be used as the root_path [default: /]")); 
    &optusg ("x", gettext ("turn on command debug at specified node(s)")); 
}

#
#:   - post_error:
#        post an error on stdout and in the node's result file. 
#
#    given:  0) a node name 
#            1) a message str
#
sub post_error {
    my ($node, $msg) = @_;

    # write to the result file and stdout
    my $res = "$TmpDir/$node.result";
    FileCache::cacheout $res;
    my $cachefile = $PkgStr . $res;

    &print_both (*STDERR, $cachefile, "($node): $ErrStr$msg\n");

    close ($cachefile);
}

#
#:   - print_both:
#        print to both stdout and the specified filehandle.
#
#    given:  0,1) two filehandles
#            2) a message str
#
sub print_both {
    my ($fh1, $fh2, $msg) = @_;

    print $fh1 $msg;
    print $fh2 $msg;

    return 1;
}

#
#:   - process_output:    
#         process the command output of a remote node. 
#
#    given: 0) a node
#           1) its log files.
#    does:  check for keywords and write the pertinent message to both 
#           standard out and the summary file.
#
sub process_output {
    my ($node, $log) = @_;

    # just in case the log file is empty
    if ( -z $log ) {
        post_error ($node, gettext ("Status unclear; check local log file and retry if needed"));
        exit (1); # exit fork
    }

    # open the log file for read
    if (! open (FH, "$log")) { 
        post_error ($node, gettext ("Failed to open $log: $!"));
        exit (1); # exit fork
    }

    # write to the result file and stdout
    my $res = "$TmpDir/$node.result";
    FileCache::cacheout $res;
    my $cachefile = $PkgStr . $res;

    my ($stat, $last);
    while (<FH>) { 
        # only look at entries with "(node): msg" format.
        # ignore shell debugging output (turned on by -x) that start with +
        $last = $_;
        if (/^[^+]*\(.+\): /) {
            s/^.*\(/\(/; # remove unwanted chars before (node): msg; eg. prompt
            if (/($DoneStr|$ErrStr)/o) {
                $stat = $_;
                last;
            } elsif (/$WarnStr/o) {
                $stat = $_;
            }
        }
    }
    close (FH);

    # if $stat is not set, we have error conditions.
    # get the last line of the log file which contains the error msg
    if (!$stat) {
        $stat = $last;
        post_error ($node, $stat);
        close ($cachefile);
        exit (1); # exit fork
    }

    &print_both (*STDOUT, $cachefile, $stat);
    close ($cachefile);

    return 1;
}

#
#:   - remove_duplicates:    
#         remove duplicates from a list 
#
#    given:  0) an array reference
#    does:   remove duplicate entries 
#
sub remove_duplicates {
    my $aref = $_[0];
    my %seen;
    @seen{@$aref} = ();
    @$aref = keys %seen;

    return 1; 
}

#
#:   - setcmdstr:    
#         set the command str based upon the backend command and the options 
#         hash.
#
#    given:  0) reference to the options hash
#    does:   sets the command string 
#
sub setcmdstr {
    my $hashref = $_[0];
    my %hash = %$hashref;

    # remove the -k/-l/-n/-N/-r/-S switches from the hash; they do not
    # get carried over to the backend commands.
    delete $hash{g};
    delete $hash{k};
    delete $hash{l};
    delete $hash{n};
    delete $hash{N};
    delete $hash{r};
    delete $hash{S};

    foreach (keys (%hash)) {
        $CmdStr .= "-$_ $hash{$_} ";
    }

    $CmdStr = "$Backend $CmdStr";

    return 1;
}

#
#:   - setnodeinfo:    
#         set the nodes array, connection method and the local flag.  
#
#    given:  0) reference to the options hash. 
#    does:   sets $Nodes, $CMethod, $LocalOp
#    return: 1 if successful, otherwise, call syntax_err and exit
#
sub setnodeinfo {
    my $hashref = $_[0];

    # are nodes specified?
    my ($use_n, $use_N);
    $use_n = 1 if (exists $hashref->{n});  
    $use_N = 1 if (exists $hashref->{N});  

    # is it local-node only?
    if (exists $hashref->{l}) {
        $LocalOp = 1;    # local operation.
        if ($use_n || $use_N) {
            &syntax_err (gettext ("-l can not be used with -n or -N"));
        }
        if (exists $hashref->{g} || exists $hashref->{k} || 
            exists $hashref->{r} || exists $hashref->{S}) { 
            &syntax_err (gettext ("-g/-k/-r/-S can only be used with -n or -N"));
        }
        return 1;
    }

    if (!$use_n && !$use_N && !$LocalOp) {
        &syntax_err (gettext ("Either -l or -n/-N must be specified"));
    }

    if (exists $hashref->{g}) {
        $GenNList = "yes";
    }

    # set the nodes array.
    if ($use_n) {
        @Nodes = split (/,/, $hashref->{n});
        foreach (@Nodes) {
            s/(^\s+|\s+$)//g;  # remove leading/trailing whitespace
        }
    }

    # get the node list from the specified file, this is accumulative with -n
    if ($use_N) {
        my $nlistfile = $hashref->{N};
        &getnodes ($nlistfile, 1, \@Nodes);
    }

    # remove duplicates, if any.
    &remove_duplicates (\@Nodes);

    (@Nodes == 0 ) && 
         &syntax_err (gettext ("No nodes specified by -n/-N")); 

    # centralized operation.
    ((exists $hashref->{x}) && (!exists $hashref->{k})) &&
        &syntax_err (gettext ("With your command option specifications, you must specify -k with -x to receive debugging output"));
    
    # is connection method specified
    (exists $hashref->{r}) || 
        &syntax_err (gettext ("Connection method must be specified. Use -r to specify"));

    ($hashref->{r} ne "rsh" && 
     $hashref->{r} ne "ssh" && $hashref->{r} ne "telnet") &&
        &syntax_err (gettext ("Supported connection methods are rsh, ssh or telnet"));
    $CMethod = $hashref->{r};

    if (exists $hashref->{S}) {
        ($CMethod ne "ssh") &&
            &syntax_err (gettext ("-S can only be used with -r ssh"));
        (-x $hashref->{S}) ||
            &syntax_err (gettext ("$hashref->{S} does not exist or is not executable"));
        $CMethodPath = $hashref->{S};        
    } else {
        # use default path (in /usr/bin)
        $CMethodPath = "/usr/bin/$CMethod";

        (-x $CMethodPath) ||
            &syntax_err (gettext ("$CMethodPath does not exist or is not executable"));
    }

    # prevent prompts from ssh.
    if ($CMethod eq 'ssh') {
        my @options;
        # if remote nodes are not in known_hosts file(s), post error instead
        # of asking.
        if (!exists $ENV{"NO_SSHOPT_HOSTKEY"}) { 
            @options = (@options, " -o StrictHostKeyChecking=yes");
        }
        # if PermitRootLogin is set to no, do not prompt for password. 
        if (!exists $ENV{"NO_SSHOPT_PASSAUTH"}) { 
            @options = (@options, " -o PasswordAuthentication=no");
        }
        foreach (@options) {
            $CMethodPath = $CMethodPath . $_; 
            print "$Script: " . gettext ("ssh is invoked with") . "$_\n";
        }
    }

    # Should we keep the log files?
    if (exists $hashref->{k}) {
        $KeepDir = $hashref->{k};  
        (-d $KeepDir && -w $KeepDir) || 
            &syntax_err (gettext ("$KeepDir is not a writable directory"));
        $KeepLogs = 1;
    }

    return 1;
}

#
#:   - syntax_err:    
#         output command usage and die with the specified message. 
#
#    given:  0) the error message 
#    return: error exit with "die" 
#
sub syntax_err {
    &main::command_usage;
    # nothing to clean up yet
    die ("$Script: $_[0].\n");
}

#
#:   - timestamp_start:    
#         start time stamps process to show progress with the use of a fifo 
#         (named pipe) 
#
#    given:  0) reference to the timestamp writer pid . 
#            1) reference to the timestamp reader pid . 
#    does:   prints timestamp and progress on stdout every 10 seconds 
#    return: 1 if successful
#
sub timestamp_start {
    
    system "mkfifo $TimeStamp";

    use FileHandle;    

    # fork a process to write to named pipe
    if (my $pid = fork) {
        # parent
        $_[0]=$pid;
    } else {
        if (! defined $pid) { 
            &fail (gettext ("Can not fork timestamp writer: $!"));
        }
        # child
        $SIG{INT} = sub { exit };
        while (1) {
            if (-p $TimeStamp) {
                sleep 10;
                open (FIFO, ">$TimeStamp") ||
                    &fail (gettext ("Failed to open $TimeStamp for writing: $!"));
                FIFO->autoflush (1);

                my $now = strftime "%c", localtime;
                print FIFO sprintf ("    %s ... %s\n", gettext ("In Progress"), $now); 
                close FIFO;
            }
        }
        exit (0);
    }

    # fork another process to read from named pipe
    if (my $pid = fork) {
        # parent
        $_[1]=$pid;
    } else {
        if (! defined $pid) { 
            &fail (gettext ("Can not fork timestamp reader: $!"));
        }
        # child
        $SIG{INT} = sub { exit };
        STDOUT->autoflush (1); 
        while (1) {
            if (-p $TimeStamp) {
                open (FIFO, "$TimeStamp") ||
                    &fail (gettext ("Failed to open $TimeStamp for reading: $!"));
                print <FIFO>; 
                close FIFO;
            }
        }
        exit (0);
    }

    return 1;
}

#
#:   - timestamp_stop:    
#         stop time stamp process 
#
#    given:  0) reference to the timestamp writer pid . 
#            1) reference to the timestamp reader pid . 
#    does:   kill both timestamp writer and reader and remove named pipe. 
#    return: 1 if successful
#
sub timestamp_stop {
    my ($writer, $reader) = @_;

    kill (9 => $writer);
    waitpid ($writer, 0);

    kill (9 => $reader);
    waitpid ($reader, 0);

    system "rm -f $TimeStamp";

    return 1;
}

#
#:   - translate_path:    
#         translate paths in the options hash to absolute paths and normalize
#         them.
#
#    given:  0) reference to the options hash. 
#    return: 1 if successful
#
sub translate_path {
    my $hashref = $_[0];

    use Cwd;
    use Cwd 'abs_path';
    use File::Spec;
    my $curdir = cwd;
    foreach my $opt ("d", "k", "N", "R", "S", "t") {
        if ((exists $hashref->{$opt}) && (!($hashref->{$opt} =~ m:^/:))) {
            # current directory
            if ($hashref->{$opt} =~ m:^.$:) {
                $hashref->{$opt} = $curdir;
                next;
            }

            # concatenate $curdir and the relative path
            my $fullpath = File::Spec->catfile ($curdir, $hashref->{$opt});
            ( -e "$fullpath" ) ||
                &fail (gettext ("$hashref->{$opt} does not exist"));

            # reset to $fullpath first
            $hashref->{$opt} = $fullpath;            

            # normalize the path if we can
            # abs_path bombs if it can't chdir to the parent directory.
            ( -o "$fullpath/.." ) || next; 

            # translate to absolute path
            my $abspath = abs_path ($fullpath);
            $hashref->{$opt} = $abspath;            
        }
    }

    return 1;
}

#
#:   - trap:    
#         interrupt trapping routine.  
#
sub trap {

    #$SIG{INT} = \$trap; # not needed on Solaris since it has reliable signals.
    print "\n";

    # restore original terminal mode just in case it's set to 'noecho'
    # when interrupted, i.e., while prompting for password.
    ReadMode (0);

    &fail (gettext ("\aCommand terminated by interruption"));
}

#
#:   - via_local_rsh_ssh:     
#         execute the command locally or via rsh/ssh.  
# 
#    given:  0) a node 
#            1) log file 
#            2) connection method (local, rsh, ssh) 
#    return: 1 if successful 
#
sub via_local_rsh_ssh {
    my ($node, $log, $method) = @_;

    my $cmd;
    if ($method eq "local") {
        $cmd = "$Lib/$CmdStr";
    } else {
        $cmd = "$CMethodPath $node -l root $Lib/$CmdStr";
    }

    # use system intead of backticks such that the log file is
    # instantaneously updated.
    system ("$cmd >$log 2>&1");
    my $ret_val = $? >> 8;    # get the exact return value
    #print "node = $node; ? = $?; ret_val = $ret_val\n"; 

    # system blocks SIGINT and SIGQUIT; check return value to see if rsh/ssh/
    # exited properly (0, 1); if not, it's an interrupt, exit fork.
    if ($ret_val > 1) {
        # workaround for bug 4685658 (/usr/bin/ssh returns 255 for both
        # success and interrupt), check the log file if this is an interrupt.
        # remove the "if" part when the bug is fixed.
        if ($method eq 'ssh' && $ret_val == 255) {
            open (FH, "$log");
            my $last;
            # for scalability reason, avoid reading the whole file in memory
            while (<FH>) { $last = $_; }
            close (FH);
            exit (1) if ($last =~ /^Killed by signal/); # ssh not localized.
        } else {
            exit (1);
        }
    }

    return 1;
}


#
#:   - via_telnet:    
#         dispatch the command to specified node using telnet and write the 
#         results to its result file. 
#
#    given:  0) a node
#            1) log file
#            2) password to the node
#    return: 1 if successful
#
sub via_telnet {
    my ($node, $log, $password) = @_;

    my $errmsg;

    my $exp = Expect->spawn("$CMethodPath $node");
    if (!$exp) {
        post_error ($node, gettext ("Failed to spawn telnet: $!"));
        exit (1); # exit fork
    }

    # turn off output of the spawned command on the invoking node
    $exp->log_stdout(0);

    # instead, log the session to a file; file logging starts instantaneously 
    $exp->log_file ($log);

    my $login;
    my $timeout = 240;         # give it 4 minutes before timing out.
    $exp->expect (
        $timeout,            
        [ qr/login: /i,     
                    sub { # try logging in only once. 
                          if (!$login) {
                              $login = 1;
                              my $fh = shift;
                              print $fh "root\n";
                              exp_continue; 
                          }
                    }],
        [ qr/password.*: /i,     
                    # allow login on system with Kerberos whose login 
                    # prompt is "Password for root: "
                    sub { my $fh = shift;
                          print $fh "$password\n"; 
                          exp_continue; 
                    }],
        [ qr/login incorrect/i,
                    # no retry when password is incorrect.
                    sub { $errmsg = gettext("Incorrect password.");
                    }],
        '-re', qr/[#>:] $/, 
    );

    # There's an error, such as timed-out, connection denied, etc. 
    # find out what the problem is from the log file
    if ($exp->exp_error() || $errmsg) {
        if (!$errmsg) {
            $errmsg = $exp->before();    
            $errmsg =~ s/[\r\n\f]/ /g;  # concatenate all lines of the error msg
            $errmsg =~ s/^\s*//;        # remove leading white space, if any 
            $errmsg =~ s/  (\w+)/. \1/g;# separate sentences.
            # just in case the error is not caught in before(); ignore lines
            # with white space only.
            $errmsg = gettext ("Failed to telnet $node as root") if ($errmsg =~ /^\s*$/);
        }
        $exp->hard_close();
        # report error and exit
        post_error ($node, $errmsg);
        exit (1); # exit fork
    }

    # issue the command
    print $exp "/bin/sh -c \"$Lib/$CmdStr\"\n";

    # wait for the last info output line from the local backend command.
    $exp->expect (undef, "-re", qr/^\s+$HistoryLog\s/); 

    # end the telnet session
    print $exp "exit\n";
    $exp->expect (undef);

    $exp->hard_close();

    return 1;
}

}        # end lexical scope

1;
