/*
 * Copyright (c) 2008 Sun Microsystem Inc. All rights reserved.
 * $COPYRIGHT$
 * 
 * Additional copyrights may follow
 * 
 * $HEADER$
 */

#ifndef _STATE_H_
#define _STATE_H_

/* OMPI STATE values for user threads */
typedef enum {
    MPI_STATE_NONE=0, /* No MPI state recorded, MPI library not loaded */
    MPI_STATE_USER,   /* thread not in the MPI library */
    MPI_STATE_PROG,   /* thread progressing communications */
    MPI_STATE_WAIT    /* thread is waiting on communications
                         as a result of no incoming data or resource
                         constraints */
} OMPI_state_t;

/* Get ompi state of current thread */
OMPI_DECLSPEC OMPI_state_t ompi_async_get_mpi_state(void *what_for);

#endif /* _STATE_H */
